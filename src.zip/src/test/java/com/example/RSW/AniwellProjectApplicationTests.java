package com.example.RSW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AniwellProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
